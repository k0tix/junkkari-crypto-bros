/**
 * Triggered from a message on a Cloud Pub/Sub topic.
 *
 * @param {!Object} event Event payload.
 * @param {!Object} context Metadata for the event.
 */
exports.pollPredict = (event, context) => {
	const https = require('node:https');
	const Knex = require('knex');

    const dbConfig = {
        client: 'pg',
        connection: {
        host: process.env.INSTANCE_HOST, // e.g. '127.0.0.1'
        port: process.env.DB_PORT, // e.g. '5432'
        user: process.env.DB_USER, // e.g. 'my-user'
        password: process.env.DB_PASS, // e.g. 'my-user-password'
        database: process.env.DB_NAME, // e.g. 'my-database'
        },
		pool: {
      		idleTimeoutMillis: 100
    	}
    };
    const kn = Knex(dbConfig);
	https.get('https://masa-image-zp5mc24kdq-ew.a.run.app/predict', (res) => {
		let body = '';
  		res.on('data', function(chunk) {
    		body += chunk;
  		});
  		res.on('end', async function() {
    		console.log(body);
			const data = JSON.parse(body.toLowerCase());
 		    await kn('data')
    		.insert(data)
			.catch((error) => console.log(error));

			await kn.destroy()
  		});
	});
};
