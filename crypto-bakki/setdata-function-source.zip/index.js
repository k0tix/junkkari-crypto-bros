const Knex = require('knex');
const fs = require('fs');

exports.createTcpPool = (req, res) => {
  const dbConfig = {
    client: 'pg',
    connection: {
      host: process.env.INSTANCE_HOST, // e.g. '127.0.0.1'
      port: process.env.DB_PORT, // e.g. '5432'
      user: process.env.DB_USER, // e.g. 'my-user'
      password: process.env.DB_PASS, // e.g. 'my-user-password'
      database: process.env.DB_NAME, // e.g. 'my-database'
    }
  };
  const kn = Knex(dbConfig);
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', '*');
  res.header('Access-Control-Allow-Headers', '*');
  kn('data')
  .insert(req.body).then((rows) => {
    res.status(200).json({"insertCount": rows.length});
  }).catch((error) => res.status(500).json(error));
};